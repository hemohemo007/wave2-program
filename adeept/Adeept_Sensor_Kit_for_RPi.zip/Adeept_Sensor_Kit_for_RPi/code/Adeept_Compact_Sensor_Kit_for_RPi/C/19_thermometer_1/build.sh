#!/bin/bash
echo "Compiling..."
gcc *.c -o main -lwiringPi
echo "Compile completed !"
